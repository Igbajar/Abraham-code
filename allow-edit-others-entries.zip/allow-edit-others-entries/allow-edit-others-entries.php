<?php
/*
Plugin Name: Allow Edit Others Entries
Description: Custom plugin to enable users to edit entries they didn't create in Gravity Forms.
Version: 1.0 
Author: Engr. Igbajar Abraham 
*/


/**
 * Allow users to edit entries they didn't create in Gravity Forms
 */
function allow_edit_others_gravity_entries( $caps, $cap, $user_id, $args ) {
    // Check if the capability being checked is to edit entries
    if ( $cap === 'gravityforms_edit_entries' ) {
        // Get the entry ID from the arguments
        $entry_id = rgar( $args, 2 );

        // Check if the current user can edit this entry
        if ( current_user_can( 'edit_others_gravity_entries' ) ) {
            // Allow editing
            $caps = array( 'edit_others_gravity_entries' );
        }
    }

    return $caps;
}
add_filter( 'map_meta_cap', 'allow_edit_others_gravity_entries', 10, 4 );
